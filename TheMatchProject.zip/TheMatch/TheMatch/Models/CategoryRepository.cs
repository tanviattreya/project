﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMatch.Models
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly UserContext _UserContext;
        public CategoryRepository(UserContext userContext)
        {
            _UserContext = userContext;
        }

        public IEnumerable<Category> AllCategories => _UserContext.Categories;
    }
}
