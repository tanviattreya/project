﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMatch.Models
{
    public class ICategoryRepository
    {
        IEnumerable<Category> AllCategories { get; }
    }
}
