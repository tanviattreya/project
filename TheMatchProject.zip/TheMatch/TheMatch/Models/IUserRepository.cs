﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMatch.Models
{
    public interface IUserRepository
    {
        User GetUserById(int Id);
    }
}
