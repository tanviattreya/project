﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace TheMatch.Models
//{
//    public class MockCategoryRepository
//    {
//        public IEnumerable<Category> AllCategories =>
//            new List<Category>
//            {
//                new Category{CategoryId=1, CategoryName="Male"},
//                new Category{CategoryId=2, CategoryName="Female"},
//                new Category{CategoryId=3, CategoryName="Both"}
//            };
//    }
//}
