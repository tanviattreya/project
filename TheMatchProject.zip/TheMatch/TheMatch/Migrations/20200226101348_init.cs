﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheMatch.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "MyProfiles",
                columns: table => new
                {
                    MyId = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MyMail = table.Column<long>(nullable: false),
                    MyName = table.Column<string>(nullable: true),
                    MyAge = table.Column<int>(nullable: false),
                    MyGender = table.Column<string>(nullable: true),
                    MyBio = table.Column<string>(nullable: true),
                    MySexual_orientation = table.Column<string>(nullable: true),
                    MyImageUrl = table.Column<string>(nullable: true),
                    MyImageThumbnailUrl = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MyProfiles", x => x.MyId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Mail = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Age = table.Column<int>(nullable: false),
                    Gender = table.Column<string>(nullable: true),
                    Bio = table.Column<string>(nullable: true),
                    Sexual_orientation = table.Column<string>(nullable: true),
                    ImageUrl = table.Column<string>(nullable: true),
                    ImageThumbnailUrl = table.Column<string>(nullable: true),
                    CategoryId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Users_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "CategoryId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName" },
                values: new object[,]
                {
                    { 1, "Male" },
                    { 2, "Female" },
                    { 3, "Both" }
                });

            migrationBuilder.InsertData(
                table: "MyProfiles",
                columns: new[] { "MyId", "MyAge", "MyBio", "MyGender", "MyImageThumbnailUrl", "MyImageUrl", "MyMail", "MyName", "MySexual_orientation" },
                values: new object[] { 1L, 22, "Hi!", "Female", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg", 0L, "Me", null });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Age", "Bio", "CategoryId", "FirstName", "Gender", "ImageThumbnailUrl", "ImageUrl", "LastName", "Mail", "Password", "Sexual_orientation" },
                values: new object[,]
                {
                    { 1L, 22, "Hey There!", null, "abc", "Male", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg", "def", null, null, null },
                    { 2L, 35, "I am a big foodie!", null, "ghi", "Female", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "jkl", null, null, null },
                    { 3L, 28, "I love books!", null, "mno", "Female", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "pqr", null, null, null },
                    { 4L, 30, "I love adventures!", null, "stu", "Male", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg", "vwx", null, null, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Users_CategoryId",
                table: "Users",
                column: "CategoryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MyProfiles");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
