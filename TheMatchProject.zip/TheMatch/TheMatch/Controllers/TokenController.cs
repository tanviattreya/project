﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using TheMatch.Models;

namespace TheMatch.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        public IConfiguration _configuration;
        private readonly UserContext _context;

        public object JwtRegisteredClaimNames { get; private set; }

        public TokenController(IConfiguration config, UserContext context)
        {
            _configuration = config;
            _context = context;
        }

        [HttpPost]
        public async Task Post(User _userData)
        {
            if (_userData != null && _userData.Mail != null && _userData.Password != null)
            {
                var user = await GetUser(_userData.Mail, _userData.Password);

                if (user != null)
                {
                    var claims = new[]
                    {
                       
                        new Claim("Id",user.Id.ToString()),
                        new Claim("FirstName",user.FirstName),
                        new Claim("LastName",user.LastName),
                        new Claim("LastName",user.LastName),
                        new Claim("Mail",user.Mail)
                    };

                }
            }
        }
        private async Task<User> GetUser(string mail, string password)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Mail == mail && u.Password == password);
        }
    }
}
